"use client"

import { motion } from 'framer-motion'
import Image from 'next/image'
import { Instagram } from 'lucide-react'

const galleryImages = [
  {
    src: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&h=400&fit=crop',
    alt: 'Coconut farm',
  },
  {
    src: 'https://images.unsplash.com/photo-1526947425960-945c6e72858f?w=400&h=400&fit=crop',
    alt: 'Coconut oil bottle',
  },
  {
    src: 'https://images.unsplash.com/photo-1591019052241-e4d95a5dc3fc?w=400&h=400&fit=crop',
    alt: 'Natural coconut oil',
  },
  {
    src: 'https://images.unsplash.com/photo-1589812308237-44843e34c9c5?w=400&h=400&fit=crop',
    alt: 'Coconut tree',
  },
  {
    src: 'https://images.unsplash.com/photo-1598046937895-2be846402e99?w=400&h=400&fit=crop',
    alt: 'Organic product',
  },
  {
    src: 'https://images.unsplash.com/photo-1505576633757-0ac1084af824?w=400&h=400&fit=crop',
    alt: 'Fresh coconuts',
  },
]

export function InstagramGallery() {
  return (
    <section className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <span className="text-[#C9A227] text-sm font-medium tracking-[0.2em] uppercase mb-2 block">
            Follow Us
          </span>
          <h2 className="font-serif text-3xl md:text-4xl lg:text-5xl text-[#123524] font-bold mb-4">
            @noyelnaturals
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Join our community and share your NOYEL Naturals experience with us.
          </p>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {galleryImages.map((image, index) => (
            <motion.a
              key={index}
              href="https://instagram.com/noyelnaturals"
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group relative aspect-square rounded-xl overflow-hidden"
            >
              <Image
                src={image.src}
                alt={image.alt}
                fill
                className="object-cover group-hover:scale-110 transition-transform duration-500"
                sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 16vw"
              />
              <div className="absolute inset-0 bg-[#123524]/0 group-hover:bg-[#123524]/60 transition-colors duration-300 flex items-center justify-center">
                <Instagram className="w-8 h-8 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </motion.a>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mt-8"
        >
          <a
            href="https://instagram.com/noyelnaturals"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 bg-[#123524] text-white rounded-lg hover:bg-[#1a4d35] transition-colors"
          >
            <Instagram className="w-5 h-5" />
            Follow on Instagram
          </a>
        </motion.div>
      </div>
    </section>
  )
}
