"use client"

import { motion } from 'framer-motion'
import Image from 'next/image'
import { Sprout, Factory, Truck, Home } from 'lucide-react'

const steps = [
  {
    icon: Sprout,
    title: 'Organic Farming',
    description: 'Coconuts grown naturally in our Udumalpet farms without chemicals or pesticides.',
    image: 'https://images.unsplash.com/photo-1589812308237-44843e34c9c5?w=400&h=300&fit=crop',
  },
  {
    icon: Factory,
    title: 'Traditional Extraction',
    description: 'Wood-pressed using the ancient chekku method to preserve all nutrients.',
    image: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=400&h=300&fit=crop',
  },
  {
    icon: Truck,
    title: 'Quality Packaging',
    description: 'Carefully bottled in eco-friendly containers to maintain freshness.',
    image: 'https://images.unsplash.com/photo-1600857544200-b2f666a9a2ec?w=400&h=300&fit=crop',
  },
  {
    icon: Home,
    title: 'Delivered Fresh',
    description: 'From our farm to your home, ensuring the purest coconut oil experience.',
    image: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=400&h=300&fit=crop',
  },
]

export function ProcessSection() {
  return (
    <section className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12 md:mb-16"
        >
          <span className="text-[#C9A227] text-sm font-medium tracking-[0.2em] uppercase mb-2 block">
            Our Process
          </span>
          <h2 className="font-serif text-3xl md:text-4xl lg:text-5xl text-[#123524] font-bold mb-4">
            From Farm to Home
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Every drop of NOYEL Naturals coconut oil goes through a careful journey 
            to bring you the purest, most authentic product.
          </p>
        </motion.div>

        <div className="relative">
          {/* Connection Line (Desktop) */}
          <div className="hidden lg:block absolute top-24 left-[12.5%] right-[12.5%] h-0.5 bg-[#C9A227]/30" />

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.2 }}
                className="relative text-center"
              >
                {/* Step Number */}
                <div className="relative z-10 w-12 h-12 bg-[#123524] text-white rounded-full flex items-center justify-center mx-auto mb-4 text-lg font-bold">
                  {index + 1}
                </div>

                {/* Icon */}
                <div className="w-16 h-16 bg-[#F8F5EF] rounded-full flex items-center justify-center mx-auto mb-4">
                  <step.icon className="w-8 h-8 text-[#C9A227]" />
                </div>

                {/* Image */}
                <div className="relative w-full aspect-[4/3] rounded-xl overflow-hidden mb-4">
                  <Image
                    src={step.image}
                    alt={step.title}
                    fill
                    className="object-cover"
                    sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
                  />
                </div>

                {/* Content */}
                <h3 className="font-serif text-xl font-semibold text-[#123524] mb-2">
                  {step.title}
                </h3>
                <p className="text-muted-foreground text-sm">
                  {step.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
