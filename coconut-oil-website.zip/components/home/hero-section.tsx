"use client"

import { motion } from 'framer-motion'
import Link from 'next/link'
import Image from 'next/image'
import { ArrowRight, Leaf, Award, Truck, Shield } from 'lucide-react'

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <Image
          src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=1920&h=1080&fit=crop"
          alt="Coconut farm"
          fill
          priority
          className="object-cover"
          sizes="100vw"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#123524]/90 via-[#123524]/70 to-[#123524]/50" />
      </div>

      {/* Content */}
      <div className="relative container mx-auto px-4 py-32 md:py-40">
        <div className="max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <span className="inline-block text-[#C9A227] text-sm md:text-base font-medium tracking-[0.3em] uppercase mb-4">
              Pure & Natural
            </span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="font-serif text-4xl md:text-5xl lg:text-7xl text-white font-bold leading-tight mb-6"
          >
            From Farm
            <br />
            <span className="text-[#C9A227]">to Home</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-lg md:text-xl text-white/80 leading-relaxed mb-8 max-w-xl"
          >
            Experience the purest form of coconut oil, traditionally wood-pressed 
            from organic farms in Udumalpet. 100% Natural, Chemical-Free.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-4"
          >
            <Link href="/shop">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="px-8 py-4 bg-[#C9A227] text-[#123524] font-semibold rounded-lg hover:bg-[#d4ad2f] transition-colors flex items-center justify-center gap-2"
              >
                Shop Now
                <ArrowRight className="w-5 h-5" />
              </motion.button>
            </Link>
            <Link href="/about">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="px-8 py-4 bg-transparent border-2 border-white text-white font-semibold rounded-lg hover:bg-white hover:text-[#123524] transition-all flex items-center justify-center gap-2"
              >
                Our Story
              </motion.button>
            </Link>
          </motion.div>
        </div>
      </div>

      {/* Trust Badges */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.8 }}
        className="absolute bottom-8 left-0 right-0"
      >
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8 max-w-4xl">
            {[
              { icon: Leaf, text: '100% Natural' },
              { icon: Award, text: 'Organic Certified' },
              { icon: Truck, text: 'Free Shipping' },
              { icon: Shield, text: 'Quality Assured' },
            ].map((item, index) => (
              <div
                key={index}
                className="flex items-center gap-2 text-white/80"
              >
                <item.icon className="w-5 h-5 text-[#C9A227]" />
                <span className="text-sm">{item.text}</span>
              </div>
            ))}
          </div>
        </div>
      </motion.div>
    </section>
  )
}
