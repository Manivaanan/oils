"use client"

import { motion } from 'framer-motion'
import Link from 'next/link'
import Image from 'next/image'
import { ArrowRight, Leaf } from 'lucide-react'

export function AboutPreview() {
  return (
    <section className="py-16 md:py-24 bg-[#F8F5EF]">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Images */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="relative z-10 rounded-2xl overflow-hidden">
              <Image
                src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&h=400&fit=crop"
                alt="Coconut farm in Udumalpet"
                width={600}
                height={400}
                className="w-full h-auto object-cover"
              />
            </div>
            <div className="absolute -bottom-8 -right-8 w-48 md:w-64 rounded-2xl overflow-hidden shadow-xl hidden md:block">
              <Image
                src="https://images.unsplash.com/photo-1589812308237-44843e34c9c5?w=300&h=300&fit=crop"
                alt="Coconut tree"
                width={300}
                height={300}
                className="w-full h-auto object-cover"
              />
            </div>
            {/* Decorative Element */}
            <div className="absolute -top-4 -left-4 w-24 h-24 bg-[#C9A227]/20 rounded-full hidden md:block" />
          </motion.div>

          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <span className="text-[#C9A227] text-sm font-medium tracking-[0.2em] uppercase mb-2 block">
              Our Story
            </span>
            <h2 className="font-serif text-3xl md:text-4xl lg:text-5xl text-[#123524] font-bold mb-6">
              Rooted in Tradition,
              <br />
              Crafted with Love
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-6">
              NOYEL Naturals was born from a simple belief - that nature provides the best. 
              Our journey began in the lush coconut farms of Udumalpet, Tamil Nadu, where 
              generations have practiced the art of traditional coconut oil extraction.
            </p>
            <p className="text-muted-foreground leading-relaxed mb-8">
              Using the time-honored wood-pressed (chekku) method, we extract pure coconut 
              oil that retains all its natural goodness. No chemicals, no shortcuts - just 
              pure, authentic coconut oil from our farm to your home.
            </p>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 mb-8">
              {[
                { value: '25+', label: 'Years Experience' },
                { value: '100%', label: 'Natural' },
                { value: '10K+', label: 'Happy Customers' },
              ].map((stat, index) => (
                <div key={index} className="text-center md:text-left">
                  <div className="font-serif text-2xl md:text-3xl font-bold text-[#123524]">
                    {stat.value}
                  </div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </div>
              ))}
            </div>

            <Link href="/about">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="inline-flex items-center gap-2 px-6 py-3 bg-[#123524] text-white rounded-lg hover:bg-[#1a4d35] transition-colors"
              >
                Learn More About Us
                <ArrowRight className="w-4 h-4" />
              </motion.button>
            </Link>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
