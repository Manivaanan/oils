"use client"

import { motion } from 'framer-motion'
import { Leaf, Heart, Shield, Sparkles, Droplets, Sun } from 'lucide-react'

const benefits = [
  {
    icon: Leaf,
    title: '100% Natural',
    description: 'Pure coconut oil with no chemicals, preservatives, or additives.',
  },
  {
    icon: Heart,
    title: 'Heart Healthy',
    description: 'Rich in good fats that support cardiovascular health.',
  },
  {
    icon: Shield,
    title: 'Boosts Immunity',
    description: 'Natural antibacterial and antiviral properties for better health.',
  },
  {
    icon: Sparkles,
    title: 'Hair & Skin Care',
    description: 'Nourishes hair follicles and provides deep skin moisturization.',
  },
  {
    icon: Droplets,
    title: 'Wood Pressed',
    description: 'Traditional extraction method preserving all natural nutrients.',
  },
  {
    icon: Sun,
    title: 'Energy Booster',
    description: 'MCTs provide quick, sustained energy throughout the day.',
  },
]

export function BenefitsSection() {
  return (
    <section className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12 md:mb-16"
        >
          <span className="text-[#C9A227] text-sm font-medium tracking-[0.2em] uppercase mb-2 block">
            Why Choose Us
          </span>
          <h2 className="font-serif text-3xl md:text-4xl lg:text-5xl text-[#123524] font-bold mb-4">
            The NOYEL Naturals Difference
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Discover the pure goodness of traditional coconut oil, crafted with 
            love and care from our organic farms.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {benefits.map((benefit, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group p-6 md:p-8 bg-[#F8F5EF] rounded-2xl hover:bg-[#123524] transition-colors duration-300"
            >
              <div className="w-14 h-14 bg-[#123524] group-hover:bg-[#C9A227] rounded-xl flex items-center justify-center mb-4 transition-colors">
                <benefit.icon className="w-7 h-7 text-[#C9A227] group-hover:text-[#123524] transition-colors" />
              </div>
              <h3 className="font-serif text-xl font-semibold text-[#123524] group-hover:text-white mb-2 transition-colors">
                {benefit.title}
              </h3>
              <p className="text-muted-foreground group-hover:text-white/80 transition-colors">
                {benefit.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
