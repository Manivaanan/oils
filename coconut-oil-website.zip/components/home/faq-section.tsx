"use client"

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Plus, Minus } from 'lucide-react'

const faqs = [
  {
    question: 'What makes NOYEL Naturals coconut oil different?',
    answer: 'Our coconut oil is extracted using traditional wood-pressed (chekku) methods from organically grown coconuts in Udumalpet, Tamil Nadu. This preserves all natural nutrients, vitamins, and the authentic aroma of fresh coconuts without any chemical processing.',
  },
  {
    question: 'Is your coconut oil suitable for cooking?',
    answer: 'Absolutely! Our coconut oil has a high smoke point, making it perfect for all types of cooking including deep frying, sautéing, and baking. The natural flavor also enhances the taste of your dishes.',
  },
  {
    question: 'Can I use this coconut oil for hair and skin?',
    answer: 'Yes! Our pure, chemical-free coconut oil is excellent for hair and skin care. It helps nourish hair follicles, promotes hair growth, moisturizes skin deeply, and can be used as a natural makeup remover.',
  },
  {
    question: 'What is the shelf life of your coconut oil?',
    answer: 'Our coconut oil has a shelf life of 12-18 months when stored properly. Keep it in a cool, dry place away from direct sunlight. The oil may solidify in cooler temperatures, which is completely natural.',
  },
  {
    question: 'Do you offer free shipping?',
    answer: 'Yes! We offer free shipping on all orders above ₹499 within India. Orders are typically delivered within 3-5 business days depending on your location.',
  },
  {
    question: 'Is your coconut oil certified organic?',
    answer: 'Yes, our coconuts are grown using organic farming practices without pesticides or chemicals. We are in the process of obtaining official organic certification from recognized bodies.',
  },
]

export function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(0)

  return (
    <section className="py-16 md:py-24 bg-[#F8F5EF]">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <span className="text-[#C9A227] text-sm font-medium tracking-[0.2em] uppercase mb-2 block">
            FAQ
          </span>
          <h2 className="font-serif text-3xl md:text-4xl lg:text-5xl text-[#123524] font-bold mb-4">
            Frequently Asked Questions
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Find answers to common questions about our products and services.
          </p>
        </motion.div>

        <div className="max-w-3xl mx-auto space-y-4">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-xl overflow-hidden shadow-sm"
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full flex items-center justify-between p-5 md:p-6 text-left hover:bg-gray-50 transition-colors"
              >
                <span className="font-semibold text-[#123524] pr-4">
                  {faq.question}
                </span>
                <span className="shrink-0 w-8 h-8 bg-[#F8F5EF] rounded-full flex items-center justify-center">
                  {openIndex === index ? (
                    <Minus className="w-4 h-4 text-[#123524]" />
                  ) : (
                    <Plus className="w-4 h-4 text-[#123524]" />
                  )}
                </span>
              </button>
              <AnimatePresence>
                {openIndex === index && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="px-5 md:px-6 pb-5 md:pb-6 text-muted-foreground">
                      {faq.answer}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
