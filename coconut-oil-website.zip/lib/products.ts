export interface Product {
  id: string
  name: string
  slug: string
  description: string
  shortDescription: string
  price: number
  originalPrice?: number
  image: string
  images: string[]
  category: string
  rating: number
  reviews: number
  size: string
  inStock: boolean
  features: string[]
  ingredients: string[]
  benefits: string[]
  isBestseller?: boolean
  isNew?: boolean
}

export const products: Product[] = [
  {
    id: '1',
    name: 'Virgin Coconut Oil',
    slug: 'virgin-coconut-oil-500ml',
    description: 'Our premium Virgin Coconut Oil is extracted from fresh coconuts using the traditional cold-pressed method. This pure, unrefined oil retains all the natural goodness and aroma of coconuts, making it perfect for cooking, skincare, and haircare. Sourced directly from our organic farms in Udumalpet, Tamil Nadu.',
    shortDescription: 'Pure cold-pressed virgin coconut oil from organic farms',
    price: 449,
    originalPrice: 549,
    image: 'https://images.unsplash.com/photo-1526947425960-945c6e72858f?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1526947425960-945c6e72858f?w=600&h=600&fit=crop',
      'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=600&h=600&fit=crop',
      'https://images.unsplash.com/photo-1591019052241-e4d95a5dc3fc?w=600&h=600&fit=crop',
    ],
    category: 'Virgin Oil',
    rating: 4.9,
    reviews: 128,
    size: '500ml',
    inStock: true,
    features: ['100% Natural', 'Cold Pressed', 'No Chemicals', 'Organic Certified'],
    ingredients: ['100% Pure Virgin Coconut Oil'],
    benefits: ['Boosts Immunity', 'Promotes Hair Growth', 'Nourishes Skin', 'Aids Digestion', 'Natural Moisturizer'],
    isBestseller: true,
  },
  {
    id: '2',
    name: 'Virgin Coconut Oil',
    slug: 'virgin-coconut-oil-1l',
    description: 'Family-size pack of our premium Virgin Coconut Oil, perfect for households that love natural cooking and wellness. This larger bottle offers excellent value while delivering the same exceptional quality and purity of our 500ml variant.',
    shortDescription: 'Family pack of pure virgin coconut oil',
    price: 799,
    originalPrice: 999,
    image: 'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=600&h=600&fit=crop',
      'https://images.unsplash.com/photo-1526947425960-945c6e72858f?w=600&h=600&fit=crop',
      'https://images.unsplash.com/photo-1591019052241-e4d95a5dc3fc?w=600&h=600&fit=crop',
    ],
    category: 'Virgin Oil',
    rating: 4.8,
    reviews: 95,
    size: '1 Litre',
    inStock: true,
    features: ['100% Natural', 'Cold Pressed', 'No Chemicals', 'Family Pack'],
    ingredients: ['100% Pure Virgin Coconut Oil'],
    benefits: ['Boosts Immunity', 'Promotes Hair Growth', 'Nourishes Skin', 'Aids Digestion', 'Natural Moisturizer'],
  },
  {
    id: '3',
    name: 'Wood Pressed Coconut Oil',
    slug: 'wood-pressed-coconut-oil',
    description: 'Traditional wood-pressed coconut oil made using the ancient chekku method passed down through generations. Our artisans use wooden cold-press machines to extract this golden oil, preserving all nutrients and the authentic aroma of fresh coconuts.',
    shortDescription: 'Traditional chekku-pressed coconut oil',
    price: 549,
    originalPrice: 649,
    image: 'https://images.unsplash.com/photo-1591019052241-e4d95a5dc3fc?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1591019052241-e4d95a5dc3fc?w=600&h=600&fit=crop',
      'https://images.unsplash.com/photo-1526947425960-945c6e72858f?w=600&h=600&fit=crop',
      'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=600&h=600&fit=crop',
    ],
    category: 'Wood Pressed',
    rating: 4.9,
    reviews: 156,
    size: '500ml',
    inStock: true,
    features: ['Wood Pressed', 'Traditional Method', 'Chemical Free', 'Rich Aroma'],
    ingredients: ['100% Pure Wood-Pressed Coconut Oil'],
    benefits: ['Heart Healthy', 'Natural Antioxidants', 'Improves Metabolism', 'Hair Nourishment', 'Skin Care'],
    isBestseller: true,
  },
  {
    id: '4',
    name: 'Cold Pressed Coconut Oil',
    slug: 'cold-pressed-coconut-oil',
    description: 'Our Cold Pressed Coconut Oil is extracted at temperatures below 50°C, ensuring maximum retention of nutrients, vitamins, and the natural goodness of coconuts. Perfect for those who want the purest form of coconut oil for their daily wellness routine.',
    shortDescription: 'Premium cold-pressed coconut oil',
    price: 499,
    originalPrice: 599,
    image: 'https://images.unsplash.com/photo-1598046937895-2be846402e99?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1598046937895-2be846402e99?w=600&h=600&fit=crop',
      'https://images.unsplash.com/photo-1526947425960-945c6e72858f?w=600&h=600&fit=crop',
      'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=600&h=600&fit=crop',
    ],
    category: 'Cold Pressed',
    rating: 4.7,
    reviews: 89,
    size: '500ml',
    inStock: true,
    features: ['Cold Pressed', 'Low Temperature', 'Nutrient Rich', 'Pure Extract'],
    ingredients: ['100% Pure Cold-Pressed Coconut Oil'],
    benefits: ['High in MCTs', 'Energy Booster', 'Weight Management', 'Brain Health', 'Immune Support'],
    isNew: true,
  },
]

export const categories = [
  { id: 'all', name: 'All Products' },
  { id: 'virgin-oil', name: 'Virgin Oil' },
  { id: 'wood-pressed', name: 'Wood Pressed' },
  { id: 'cold-pressed', name: 'Cold Pressed' },
]

export function getProductBySlug(slug: string): Product | undefined {
  return products.find((product) => product.slug === slug)
}

export function getProductById(id: string): Product | undefined {
  return products.find((product) => product.id === id)
}

export function getRelatedProducts(currentId: string, limit = 3): Product[] {
  return products.filter((product) => product.id !== currentId).slice(0, limit)
}
