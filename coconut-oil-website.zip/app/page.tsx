import { HeroSection } from '@/components/home/hero-section'
import { BenefitsSection } from '@/components/home/benefits-section'
import { FeaturedProducts } from '@/components/home/featured-products'
import { ProcessSection } from '@/components/home/process-section'
import { AboutPreview } from '@/components/home/about-preview'
import { TestimonialsSection } from '@/components/home/testimonials-section'
import { FAQSection } from '@/components/home/faq-section'
import { InstagramGallery } from '@/components/home/instagram-gallery'
import { CTASection } from '@/components/home/cta-section'

export default function HomePage() {
  return (
    <>
      <HeroSection />
      <BenefitsSection />
      <FeaturedProducts />
      <AboutPreview />
      <ProcessSection />
      <TestimonialsSection />
      <FAQSection />
      <InstagramGallery />
      <CTASection />
    </>
  )
}
