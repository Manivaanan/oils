import type { Metadata } from 'next'
import { Playfair_Display, Montserrat } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'
import { Header } from '@/components/layout/header'
import { Footer } from '@/components/layout/footer'
import { WhatsAppButton } from '@/components/ui/whatsapp-button'
import { CartProvider } from '@/lib/cart-context'

const playfair = Playfair_Display({ 
  subsets: ['latin'],
  variable: '--font-playfair',
  display: 'swap',
})

const montserrat = Montserrat({ 
  subsets: ['latin'],
  variable: '--font-montserrat',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'NOYEL Naturals - Premium Coconut Oil | From Farm to Home',
  description: 'Experience the purest wood-pressed and cold-pressed coconut oil from Udumalpet farms. 100% natural, chemical-free, traditional South Indian organic wellness.',
  keywords: 'coconut oil, virgin coconut oil, wood pressed, cold pressed, organic, natural, Udumalpet, South India',
  openGraph: {
    title: 'NOYEL Naturals - Premium Coconut Oil',
    description: 'From Farm to Home - Pure, Natural, Traditional coconut oil',
    type: 'website',
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${playfair.variable} ${montserrat.variable} bg-background`}>
      <body className="font-sans antialiased">
        <CartProvider>
          <Header />
          <main>{children}</main>
          <Footer />
          <WhatsAppButton />
        </CartProvider>
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
