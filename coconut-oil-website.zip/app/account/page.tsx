"use client"

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import Image from 'next/image'
import { User, Package, MapPin, LogOut, Mail, Lock, Eye, EyeOff, Phone, ChevronRight } from 'lucide-react'

type Tab = 'login' | 'register' | 'dashboard' | 'orders' | 'addresses' | 'profile'

const mockOrders = [
  {
    id: 'NOY-12345678',
    date: '2024-01-15',
    status: 'Delivered',
    total: 898,
    items: [
      { name: 'Virgin Coconut Oil 500ml', quantity: 2, price: 449 },
    ],
  },
  {
    id: 'NOY-12345679',
    date: '2024-01-10',
    status: 'Processing',
    total: 549,
    items: [
      { name: 'Wood Pressed Coconut Oil', quantity: 1, price: 549 },
    ],
  },
]

export default function AccountPage() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [activeTab, setActiveTab] = useState<Tab>('login')
  const [showPassword, setShowPassword] = useState(false)
  const [loginForm, setLoginForm] = useState({ email: '', password: '' })
  const [registerForm, setRegisterForm] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
  })

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    // Simulate login
    setIsLoggedIn(true)
    setActiveTab('dashboard')
  }

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault()
    // Simulate registration
    setIsLoggedIn(true)
    setActiveTab('dashboard')
  }

  const handleLogout = () => {
    setIsLoggedIn(false)
    setActiveTab('login')
  }

  // Auth Forms
  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-[#F8F5EF]">
        {/* Hero Section */}
        <section className="bg-[#123524] pt-32 pb-16 md:pt-40 md:pb-20">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center"
            >
              <h1 className="font-serif text-4xl md:text-5xl text-white font-bold mb-4">
                {activeTab === 'login' ? 'Welcome Back' : 'Create Account'}
              </h1>
              <p className="text-white/80">
                {activeTab === 'login'
                  ? 'Sign in to access your account'
                  : 'Join the NOYEL Naturals family'}
              </p>
            </motion.div>
          </div>
        </section>

        {/* Auth Form */}
        <section className="py-12 md:py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-md mx-auto">
              {/* Tab Switcher */}
              <div className="flex bg-white rounded-lg p-1 mb-8 shadow-sm">
                <button
                  onClick={() => setActiveTab('login')}
                  className={`flex-1 py-2 rounded-md text-sm font-medium transition-colors ${
                    activeTab === 'login'
                      ? 'bg-[#123524] text-white'
                      : 'text-muted-foreground hover:text-[#123524]'
                  }`}
                >
                  Sign In
                </button>
                <button
                  onClick={() => setActiveTab('register')}
                  className={`flex-1 py-2 rounded-md text-sm font-medium transition-colors ${
                    activeTab === 'register'
                      ? 'bg-[#123524] text-white'
                      : 'text-muted-foreground hover:text-[#123524]'
                  }`}
                >
                  Register
                </button>
              </div>

              <AnimatePresence mode="wait">
                {activeTab === 'login' && (
                  <motion.div
                    key="login"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    className="bg-white p-6 md:p-8 rounded-2xl shadow-lg"
                  >
                    <form onSubmit={handleLogin} className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-[#123524] mb-1">
                          Email Address
                        </label>
                        <div className="relative">
                          <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                          <input
                            type="email"
                            required
                            value={loginForm.email}
                            onChange={(e) =>
                              setLoginForm({ ...loginForm, email: e.target.value })
                            }
                            className="w-full pl-10 pr-4 py-3 bg-[#F8F5EF] border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-[#123524]"
                            placeholder="you@example.com"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-[#123524] mb-1">
                          Password
                        </label>
                        <div className="relative">
                          <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                          <input
                            type={showPassword ? 'text' : 'password'}
                            required
                            value={loginForm.password}
                            onChange={(e) =>
                              setLoginForm({ ...loginForm, password: e.target.value })
                            }
                            className="w-full pl-10 pr-12 py-3 bg-[#F8F5EF] border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-[#123524]"
                            placeholder="Enter password"
                          />
                          <button
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                          >
                            {showPassword ? (
                              <EyeOff className="w-5 h-5" />
                            ) : (
                              <Eye className="w-5 h-5" />
                            )}
                          </button>
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input
                            type="checkbox"
                            className="w-4 h-4 rounded border-border text-[#123524] focus:ring-[#123524]"
                          />
                          <span className="text-sm text-muted-foreground">
                            Remember me
                          </span>
                        </label>
                        <a
                          href="#"
                          className="text-sm text-[#123524] hover:underline"
                        >
                          Forgot password?
                        </a>
                      </div>

                      <motion.button
                        type="submit"
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        className="w-full py-3 bg-[#123524] text-white font-semibold rounded-lg hover:bg-[#1a4d35] transition-colors"
                      >
                        Sign In
                      </motion.button>
                    </form>
                  </motion.div>
                )}

                {activeTab === 'register' && (
                  <motion.div
                    key="register"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="bg-white p-6 md:p-8 rounded-2xl shadow-lg"
                  >
                    <form onSubmit={handleRegister} className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-[#123524] mb-1">
                          Full Name
                        </label>
                        <div className="relative">
                          <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                          <input
                            type="text"
                            required
                            value={registerForm.name}
                            onChange={(e) =>
                              setRegisterForm({ ...registerForm, name: e.target.value })
                            }
                            className="w-full pl-10 pr-4 py-3 bg-[#F8F5EF] border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-[#123524]"
                            placeholder="John Doe"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-[#123524] mb-1">
                          Email Address
                        </label>
                        <div className="relative">
                          <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                          <input
                            type="email"
                            required
                            value={registerForm.email}
                            onChange={(e) =>
                              setRegisterForm({ ...registerForm, email: e.target.value })
                            }
                            className="w-full pl-10 pr-4 py-3 bg-[#F8F5EF] border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-[#123524]"
                            placeholder="you@example.com"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-[#123524] mb-1">
                          Phone Number
                        </label>
                        <div className="relative">
                          <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                          <input
                            type="tel"
                            required
                            value={registerForm.phone}
                            onChange={(e) =>
                              setRegisterForm({ ...registerForm, phone: e.target.value })
                            }
                            className="w-full pl-10 pr-4 py-3 bg-[#F8F5EF] border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-[#123524]"
                            placeholder="+91 98765 43210"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-[#123524] mb-1">
                          Password
                        </label>
                        <div className="relative">
                          <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                          <input
                            type={showPassword ? 'text' : 'password'}
                            required
                            value={registerForm.password}
                            onChange={(e) =>
                              setRegisterForm({
                                ...registerForm,
                                password: e.target.value,
                              })
                            }
                            className="w-full pl-10 pr-12 py-3 bg-[#F8F5EF] border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-[#123524]"
                            placeholder="Create password"
                          />
                          <button
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                          >
                            {showPassword ? (
                              <EyeOff className="w-5 h-5" />
                            ) : (
                              <Eye className="w-5 h-5" />
                            )}
                          </button>
                        </div>
                      </div>

                      <motion.button
                        type="submit"
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        className="w-full py-3 bg-[#123524] text-white font-semibold rounded-lg hover:bg-[#1a4d35] transition-colors"
                      >
                        Create Account
                      </motion.button>

                      <p className="text-xs text-center text-muted-foreground">
                        By creating an account, you agree to our{' '}
                        <a href="#" className="text-[#123524] hover:underline">
                          Terms of Service
                        </a>{' '}
                        and{' '}
                        <a href="#" className="text-[#123524] hover:underline">
                          Privacy Policy
                        </a>
                      </p>
                    </form>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </section>
      </div>
    )
  }

  // Dashboard
  return (
    <div className="min-h-screen bg-[#F8F5EF]">
      {/* Hero Section */}
      <section className="bg-[#123524] pt-32 pb-12 md:pt-40 md:pb-16">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col md:flex-row items-center gap-6"
          >
            <div className="w-20 h-20 bg-[#C9A227] rounded-full flex items-center justify-center">
              <User className="w-10 h-10 text-[#123524]" />
            </div>
            <div className="text-center md:text-left">
              <h1 className="font-serif text-3xl md:text-4xl text-white font-bold mb-1">
                Welcome, Customer!
              </h1>
              <p className="text-white/70">Manage your account and orders</p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Dashboard Content */}
      <section className="py-8 md:py-12">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-4 gap-8">
            {/* Sidebar */}
            <div className="lg:col-span-1">
              <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
                {[
                  { id: 'dashboard', icon: User, label: 'Dashboard' },
                  { id: 'orders', icon: Package, label: 'My Orders' },
                  { id: 'addresses', icon: MapPin, label: 'Addresses' },
                  { id: 'profile', icon: User, label: 'Profile Settings' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id as Tab)}
                    className={`w-full flex items-center gap-3 px-4 py-3 text-left transition-colors ${
                      activeTab === item.id
                        ? 'bg-[#123524] text-white'
                        : 'text-[#123524] hover:bg-[#F8F5EF]'
                    }`}
                  >
                    <item.icon className="w-5 h-5" />
                    <span className="font-medium">{item.label}</span>
                    <ChevronRight className="w-4 h-4 ml-auto" />
                  </button>
                ))}
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center gap-3 px-4 py-3 text-left text-red-500 hover:bg-red-50 transition-colors border-t border-border"
                >
                  <LogOut className="w-5 h-5" />
                  <span className="font-medium">Sign Out</span>
                </button>
              </div>
            </div>

            {/* Main Content */}
            <div className="lg:col-span-3">
              <AnimatePresence mode="wait">
                {activeTab === 'dashboard' && (
                  <motion.div
                    key="dashboard"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="space-y-6"
                  >
                    {/* Stats */}
                    <div className="grid sm:grid-cols-3 gap-4">
                      {[
                        { label: 'Total Orders', value: '2' },
                        { label: 'Wishlist', value: '4' },
                        { label: 'Rewards Points', value: '150' },
                      ].map((stat, index) => (
                        <div
                          key={index}
                          className="bg-white p-6 rounded-xl shadow-sm text-center"
                        >
                          <div className="font-serif text-3xl font-bold text-[#123524]">
                            {stat.value}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {stat.label}
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Recent Orders */}
                    <div className="bg-white rounded-2xl shadow-sm p-6">
                      <h2 className="font-serif text-xl font-bold text-[#123524] mb-4">
                        Recent Orders
                      </h2>
                      <div className="space-y-4">
                        {mockOrders.slice(0, 2).map((order) => (
                          <div
                            key={order.id}
                            className="flex items-center justify-between p-4 bg-[#F8F5EF] rounded-xl"
                          >
                            <div>
                              <p className="font-medium text-[#123524]">
                                {order.id}
                              </p>
                              <p className="text-sm text-muted-foreground">
                                {order.date}
                              </p>
                            </div>
                            <div className="text-right">
                              <span
                                className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${
                                  order.status === 'Delivered'
                                    ? 'bg-green-100 text-green-700'
                                    : 'bg-yellow-100 text-yellow-700'
                                }`}
                              >
                                {order.status}
                              </span>
                              <p className="text-sm font-medium mt-1">
                                ₹{order.total}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                )}

                {activeTab === 'orders' && (
                  <motion.div
                    key="orders"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="bg-white rounded-2xl shadow-sm p-6"
                  >
                    <h2 className="font-serif text-xl font-bold text-[#123524] mb-6">
                      Order History
                    </h2>
                    <div className="space-y-4">
                      {mockOrders.map((order) => (
                        <div
                          key={order.id}
                          className="border border-border rounded-xl p-4"
                        >
                          <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
                            <div>
                              <p className="font-mono font-medium text-[#123524]">
                                {order.id}
                              </p>
                              <p className="text-sm text-muted-foreground">
                                Placed on {order.date}
                              </p>
                            </div>
                            <span
                              className={`px-3 py-1 rounded-full text-xs font-medium ${
                                order.status === 'Delivered'
                                  ? 'bg-green-100 text-green-700'
                                  : 'bg-yellow-100 text-yellow-700'
                              }`}
                            >
                              {order.status}
                            </span>
                          </div>
                          <div className="space-y-2">
                            {order.items.map((item, index) => (
                              <div
                                key={index}
                                className="flex justify-between text-sm"
                              >
                                <span>
                                  {item.name} x {item.quantity}
                                </span>
                                <span className="font-medium">
                                  ₹{item.price * item.quantity}
                                </span>
                              </div>
                            ))}
                          </div>
                          <div className="border-t border-border mt-4 pt-4 flex justify-between">
                            <span className="font-medium">Total</span>
                            <span className="font-bold text-[#123524]">
                              ₹{order.total}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}

                {activeTab === 'addresses' && (
                  <motion.div
                    key="addresses"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="bg-white rounded-2xl shadow-sm p-6"
                  >
                    <div className="flex items-center justify-between mb-6">
                      <h2 className="font-serif text-xl font-bold text-[#123524]">
                        Saved Addresses
                      </h2>
                      <button className="text-sm font-medium text-[#123524] hover:underline">
                        + Add New
                      </button>
                    </div>
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div className="border border-border rounded-xl p-4">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="px-2 py-0.5 bg-[#123524] text-white text-xs rounded">
                            Home
                          </span>
                          <span className="text-xs text-muted-foreground">
                            Default
                          </span>
                        </div>
                        <p className="text-sm text-[#123524] mb-1">
                          John Doe
                        </p>
                        <p className="text-sm text-muted-foreground">
                          123, Main Street
                          <br />
                          Chennai, Tamil Nadu - 600001
                          <br />
                          Phone: +91 98765 43210
                        </p>
                      </div>
                    </div>
                  </motion.div>
                )}

                {activeTab === 'profile' && (
                  <motion.div
                    key="profile"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="bg-white rounded-2xl shadow-sm p-6"
                  >
                    <h2 className="font-serif text-xl font-bold text-[#123524] mb-6">
                      Profile Settings
                    </h2>
                    <form className="space-y-4 max-w-md">
                      <div>
                        <label className="block text-sm font-medium text-[#123524] mb-1">
                          Full Name
                        </label>
                        <input
                          type="text"
                          defaultValue="John Doe"
                          className="w-full px-4 py-3 bg-[#F8F5EF] border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-[#123524]"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-[#123524] mb-1">
                          Email Address
                        </label>
                        <input
                          type="email"
                          defaultValue="john@example.com"
                          className="w-full px-4 py-3 bg-[#F8F5EF] border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-[#123524]"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-[#123524] mb-1">
                          Phone Number
                        </label>
                        <input
                          type="tel"
                          defaultValue="+91 98765 43210"
                          className="w-full px-4 py-3 bg-[#F8F5EF] border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-[#123524]"
                        />
                      </div>
                      <button
                        type="submit"
                        className="px-6 py-3 bg-[#123524] text-white font-semibold rounded-lg hover:bg-[#1a4d35] transition-colors"
                      >
                        Save Changes
                      </button>
                    </form>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
