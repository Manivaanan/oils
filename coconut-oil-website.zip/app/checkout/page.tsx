"use client"

import { useState } from 'react'
import { motion } from 'framer-motion'
import Image from 'next/image'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { ArrowLeft, CreditCard, Truck, Shield, Check } from 'lucide-react'
import { useCart } from '@/lib/cart-context'

export default function CheckoutPage() {
  const router = useRouter()
  const { items, totalPrice, clearCart } = useCart()
  const [step, setStep] = useState(1)
  const [isProcessing, setIsProcessing] = useState(false)
  const [formData, setFormData] = useState({
    email: '',
    firstName: '',
    lastName: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    pincode: '',
    sameAsBilling: true,
    paymentMethod: 'cod',
  })

  const shipping = totalPrice >= 499 ? 0 : 50
  const finalTotal = totalPrice + shipping

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value,
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsProcessing(true)

    // Simulate order processing
    await new Promise((resolve) => setTimeout(resolve, 2000))

    clearCart()
    setStep(3) // Order confirmation
    setIsProcessing(false)
  }

  if (items.length === 0 && step !== 3) {
    return (
      <div className="min-h-screen bg-[#F8F5EF] pt-32 pb-16">
        <div className="container mx-auto px-4">
          <div className="max-w-lg mx-auto text-center py-16">
            <h1 className="font-serif text-3xl font-bold text-[#123524] mb-4">
              No Items to Checkout
            </h1>
            <p className="text-muted-foreground mb-8">
              Add some products to your cart before proceeding to checkout.
            </p>
            <Link href="/shop">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="inline-flex items-center gap-2 px-6 py-3 bg-[#123524] text-white font-semibold rounded-lg"
              >
                <ArrowLeft className="w-5 h-5" />
                Browse Products
              </motion.button>
            </Link>
          </div>
        </div>
      </div>
    )
  }

  // Order Confirmation
  if (step === 3) {
    return (
      <div className="min-h-screen bg-[#F8F5EF] pt-32 pb-16">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-lg mx-auto text-center py-16"
          >
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Check className="w-10 h-10 text-green-600" />
            </div>
            <h1 className="font-serif text-3xl font-bold text-[#123524] mb-4">
              Order Confirmed!
            </h1>
            <p className="text-muted-foreground mb-2">
              Thank you for your order. We&apos;ve received your order and will begin 
              processing it right away.
            </p>
            <p className="text-muted-foreground mb-8">
              Order confirmation has been sent to your email.
            </p>
            <div className="bg-white p-6 rounded-xl mb-8">
              <p className="text-sm text-muted-foreground mb-1">Order Number</p>
              <p className="font-mono text-lg font-bold text-[#123524]">
                NOY-{Date.now().toString().slice(-8)}
              </p>
            </div>
            <Link href="/shop">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="inline-flex items-center gap-2 px-6 py-3 bg-[#123524] text-white font-semibold rounded-lg"
              >
                Continue Shopping
              </motion.button>
            </Link>
          </motion.div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#F8F5EF]">
      {/* Header */}
      <section className="bg-[#123524] pt-32 pb-8 md:pt-40 md:pb-12">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <h1 className="font-serif text-4xl md:text-5xl text-white font-bold mb-4">
              Checkout
            </h1>
            
            {/* Progress Steps */}
            <div className="flex items-center justify-center gap-4 mt-6">
              {['Details', 'Payment', 'Confirm'].map((label, index) => (
                <div key={label} className="flex items-center gap-2">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                      step > index + 1
                        ? 'bg-[#C9A227] text-[#123524]'
                        : step === index + 1
                        ? 'bg-white text-[#123524]'
                        : 'bg-white/20 text-white/60'
                    }`}
                  >
                    {step > index + 1 ? <Check className="w-4 h-4" /> : index + 1}
                  </div>
                  <span
                    className={`text-sm hidden sm:block ${
                      step >= index + 1 ? 'text-white' : 'text-white/60'
                    }`}
                  >
                    {label}
                  </span>
                  {index < 2 && (
                    <div className={`w-8 md:w-16 h-0.5 ${step > index + 1 ? 'bg-[#C9A227]' : 'bg-white/20'}`} />
                  )}
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Checkout Content */}
      <section className="py-8 md:py-12">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Form */}
            <div className="lg:col-span-2">
              <form onSubmit={handleSubmit}>
                {step === 1 && (
                  <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="space-y-6"
                  >
                    {/* Contact Information */}
                    <div className="bg-white p-6 rounded-2xl shadow-sm">
                      <h2 className="font-serif text-xl font-bold text-[#123524] mb-4">
                        Contact Information
                      </h2>
                      <div className="grid sm:grid-cols-2 gap-4">
                        <div className="sm:col-span-2">
                          <label className="block text-sm font-medium text-[#123524] mb-1">
                            Email Address *
                          </label>
                          <input
                            type="email"
                            name="email"
                            required
                            value={formData.email}
                            onChange={handleInputChange}
                            className="w-full px-4 py-3 bg-[#F8F5EF] border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-[#123524]"
                            placeholder="you@example.com"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-[#123524] mb-1">
                            First Name *
                          </label>
                          <input
                            type="text"
                            name="firstName"
                            required
                            value={formData.firstName}
                            onChange={handleInputChange}
                            className="w-full px-4 py-3 bg-[#F8F5EF] border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-[#123524]"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-[#123524] mb-1">
                            Last Name *
                          </label>
                          <input
                            type="text"
                            name="lastName"
                            required
                            value={formData.lastName}
                            onChange={handleInputChange}
                            className="w-full px-4 py-3 bg-[#F8F5EF] border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-[#123524]"
                          />
                        </div>
                        <div className="sm:col-span-2">
                          <label className="block text-sm font-medium text-[#123524] mb-1">
                            Phone Number *
                          </label>
                          <input
                            type="tel"
                            name="phone"
                            required
                            value={formData.phone}
                            onChange={handleInputChange}
                            className="w-full px-4 py-3 bg-[#F8F5EF] border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-[#123524]"
                            placeholder="+91 98765 43210"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Shipping Address */}
                    <div className="bg-white p-6 rounded-2xl shadow-sm">
                      <h2 className="font-serif text-xl font-bold text-[#123524] mb-4">
                        Shipping Address
                      </h2>
                      <div className="grid sm:grid-cols-2 gap-4">
                        <div className="sm:col-span-2">
                          <label className="block text-sm font-medium text-[#123524] mb-1">
                            Address *
                          </label>
                          <input
                            type="text"
                            name="address"
                            required
                            value={formData.address}
                            onChange={handleInputChange}
                            className="w-full px-4 py-3 bg-[#F8F5EF] border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-[#123524]"
                            placeholder="House number, Street name"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-[#123524] mb-1">
                            City *
                          </label>
                          <input
                            type="text"
                            name="city"
                            required
                            value={formData.city}
                            onChange={handleInputChange}
                            className="w-full px-4 py-3 bg-[#F8F5EF] border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-[#123524]"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-[#123524] mb-1">
                            State *
                          </label>
                          <select
                            name="state"
                            required
                            value={formData.state}
                            onChange={handleInputChange}
                            className="w-full px-4 py-3 bg-[#F8F5EF] border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-[#123524]"
                          >
                            <option value="">Select state</option>
                            <option value="TN">Tamil Nadu</option>
                            <option value="KA">Karnataka</option>
                            <option value="KL">Kerala</option>
                            <option value="AP">Andhra Pradesh</option>
                            <option value="MH">Maharashtra</option>
                            <option value="DL">Delhi</option>
                            <option value="other">Other</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-[#123524] mb-1">
                            PIN Code *
                          </label>
                          <input
                            type="text"
                            name="pincode"
                            required
                            value={formData.pincode}
                            onChange={handleInputChange}
                            className="w-full px-4 py-3 bg-[#F8F5EF] border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-[#123524]"
                            placeholder="642126"
                          />
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => setStep(2)}
                      className="w-full py-3 bg-[#123524] text-white font-semibold rounded-lg hover:bg-[#1a4d35] transition-colors"
                    >
                      Continue to Payment
                    </button>
                  </motion.div>
                )}

                {step === 2 && (
                  <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="space-y-6"
                  >
                    {/* Payment Method */}
                    <div className="bg-white p-6 rounded-2xl shadow-sm">
                      <h2 className="font-serif text-xl font-bold text-[#123524] mb-4">
                        Payment Method
                      </h2>
                      <div className="space-y-3">
                        {[
                          { id: 'cod', label: 'Cash on Delivery', icon: Truck },
                          { id: 'card', label: 'Credit/Debit Card', icon: CreditCard },
                          { id: 'upi', label: 'UPI Payment', icon: Shield },
                        ].map((method) => (
                          <label
                            key={method.id}
                            className={`flex items-center gap-4 p-4 rounded-xl border-2 cursor-pointer transition-colors ${
                              formData.paymentMethod === method.id
                                ? 'border-[#123524] bg-[#123524]/5'
                                : 'border-border hover:border-[#123524]/50'
                            }`}
                          >
                            <input
                              type="radio"
                              name="paymentMethod"
                              value={method.id}
                              checked={formData.paymentMethod === method.id}
                              onChange={handleInputChange}
                              className="sr-only"
                            />
                            <method.icon className="w-6 h-6 text-[#123524]" />
                            <span className="font-medium text-[#123524]">
                              {method.label}
                            </span>
                            {formData.paymentMethod === method.id && (
                              <Check className="w-5 h-5 text-[#123524] ml-auto" />
                            )}
                          </label>
                        ))}
                      </div>

                      {formData.paymentMethod === 'card' && (
                        <div className="mt-6 p-4 bg-[#F8F5EF] rounded-xl">
                          <p className="text-sm text-muted-foreground text-center">
                            Card payment integration coming soon. Please use Cash on Delivery or UPI for now.
                          </p>
                        </div>
                      )}
                    </div>

                    <div className="flex gap-4">
                      <button
                        type="button"
                        onClick={() => setStep(1)}
                        className="flex-1 py-3 border-2 border-[#123524] text-[#123524] font-semibold rounded-lg hover:bg-[#123524]/5 transition-colors"
                      >
                        Back
                      </button>
                      <button
                        type="submit"
                        disabled={isProcessing}
                        className="flex-1 py-3 bg-[#C9A227] text-[#123524] font-semibold rounded-lg hover:bg-[#d4ad2f] transition-colors disabled:opacity-50"
                      >
                        {isProcessing ? 'Processing...' : 'Place Order'}
                      </button>
                    </div>
                  </motion.div>
                )}
              </form>
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <div className="bg-white rounded-2xl shadow-sm p-6 sticky top-24">
                <h2 className="font-serif text-xl font-bold text-[#123524] mb-6">
                  Order Summary
                </h2>

                {/* Items */}
                <div className="space-y-4 mb-6">
                  {items.map((item) => (
                    <div key={item.id} className="flex gap-3">
                      <div className="relative w-16 h-16 rounded-lg overflow-hidden bg-[#F8F5EF] shrink-0">
                        <Image
                          src={item.image}
                          alt={item.name}
                          fill
                          className="object-cover"
                          sizes="64px"
                        />
                        <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#123524] text-white text-xs rounded-full flex items-center justify-center">
                          {item.quantity}
                        </span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-sm text-[#123524] truncate">
                          {item.name}
                        </h4>
                        <p className="text-xs text-muted-foreground">{item.size}</p>
                      </div>
                      <span className="text-sm font-medium">
                        ₹{item.price * item.quantity}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Totals */}
                <div className="space-y-2 border-t border-border pt-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span>₹{totalPrice}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Shipping</span>
                    <span>{shipping === 0 ? 'Free' : `₹${shipping}`}</span>
                  </div>
                  <div className="flex justify-between text-lg font-bold text-[#123524] border-t border-border pt-2">
                    <span>Total</span>
                    <span>₹{finalTotal}</span>
                  </div>
                </div>

                {/* Trust Badge */}
                <div className="mt-6 flex items-center justify-center gap-2 text-sm text-muted-foreground">
                  <Shield className="w-4 h-4" />
                  <span>Secure Checkout</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
