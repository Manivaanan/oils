"use client"

import { motion } from 'framer-motion'
import Image from 'next/image'
import { Leaf, Heart, Award, Users, Globe, TreePine } from 'lucide-react'

const values = [
  {
    icon: Leaf,
    title: 'Pure & Natural',
    description: 'Every drop of our oil is 100% pure, extracted without chemicals or additives.',
  },
  {
    icon: Heart,
    title: 'Made with Love',
    description: 'Crafted by local artisans who have mastered the traditional extraction process.',
  },
  {
    icon: Award,
    title: 'Quality First',
    description: 'Rigorous quality checks at every stage ensure you get the best product.',
  },
  {
    icon: Users,
    title: 'Community Support',
    description: 'Supporting local farmers and empowering rural communities in Udumalpet.',
  },
  {
    icon: Globe,
    title: 'Sustainable',
    description: 'Eco-friendly practices from farming to packaging to reduce environmental impact.',
  },
  {
    icon: TreePine,
    title: 'Organic Farming',
    description: 'Our coconuts are grown naturally without pesticides or harmful chemicals.',
  },
]

const milestones = [
  { year: '1998', title: 'The Beginning', description: 'Started with a small coconut farm in Udumalpet.' },
  { year: '2005', title: 'Traditional Methods', description: 'Revived the ancient wood-pressed extraction technique.' },
  { year: '2015', title: 'Growing Family', description: 'Expanded to support 50+ local farming families.' },
  { year: '2020', title: 'Online Launch', description: 'Brought farm-fresh coconut oil to homes nationwide.' },
  { year: '2024', title: 'NOYEL Naturals', description: 'Rebranded with a mission to reach every Indian home.' },
]

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-[#F8F5EF]">
      {/* Hero Section */}
      <section className="relative bg-[#123524] pt-32 pb-20 md:pt-40 md:pb-32 overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <Image
            src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=1920&h=800&fit=crop"
            alt="Coconut farm background"
            fill
            className="object-cover"
            sizes="100vw"
          />
        </div>
        <div className="container mx-auto px-4 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl mx-auto text-center"
          >
            <span className="text-[#C9A227] text-sm font-medium tracking-[0.2em] uppercase mb-4 block">
              Our Story
            </span>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-white font-bold mb-6">
              Rooted in Tradition,
              <br />
              Growing with Purpose
            </h1>
            <p className="text-white/80 text-lg leading-relaxed">
              From the lush coconut farms of Udumalpet to homes across India, 
              our journey is one of passion, tradition, and commitment to natural wellness.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="order-2 lg:order-1"
            >
              <span className="text-[#C9A227] text-sm font-medium tracking-[0.2em] uppercase mb-2 block">
                How It Started
              </span>
              <h2 className="font-serif text-3xl md:text-4xl text-[#123524] font-bold mb-6">
                A Family Legacy of Pure Goodness
              </h2>
              <div className="space-y-4 text-muted-foreground leading-relaxed">
                <p>
                  NOYEL Naturals began as a humble family venture in the heart of Udumalpet, 
                  Tamil Nadu - a region blessed with fertile soil and ideal conditions for 
                  growing the finest coconuts.
                </p>
                <p>
                  For generations, our family has practiced the traditional art of extracting 
                  coconut oil using the wood-pressed (chekku) method. This ancient technique, 
                  passed down through our ancestors, ensures that every drop of oil retains 
                  its natural nutrients, aroma, and goodness.
                </p>
                <p>
                  What started in our family kitchen has now grown into a mission - to bring 
                  the authentic taste and health benefits of pure coconut oil to every 
                  Indian household. We believe that nature provides the best, and our role 
                  is simply to preserve and deliver its gifts without compromise.
                </p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="order-1 lg:order-2 relative"
            >
              <div className="relative rounded-2xl overflow-hidden">
                <Image
                  src="https://images.unsplash.com/photo-1589812308237-44843e34c9c5?w=600&h=500&fit=crop"
                  alt="Coconut farm in Udumalpet"
                  width={600}
                  height={500}
                  className="w-full h-auto object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -left-6 bg-[#123524] text-white p-6 rounded-xl hidden md:block">
                <div className="text-4xl font-serif font-bold text-[#C9A227]">25+</div>
                <div className="text-sm">Years of Excellence</div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-16 md:py-24 bg-white">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <span className="text-[#C9A227] text-sm font-medium tracking-[0.2em] uppercase mb-2 block">
              Traditional Process
            </span>
            <h2 className="font-serif text-3xl md:text-4xl text-[#123524] font-bold mb-4">
              The Wood-Pressed Difference
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Our traditional extraction method preserves the authentic essence of coconut oil.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8 lg:gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <div className="relative rounded-2xl overflow-hidden">
                <Image
                  src="https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=600&h=400&fit=crop"
                  alt="Traditional wood pressing"
                  width={600}
                  height={400}
                  className="w-full h-auto object-cover"
                />
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="space-y-6"
            >
              {[
                {
                  title: 'Handpicked Coconuts',
                  description: 'We carefully select mature coconuts from our organic farms.',
                },
                {
                  title: 'Traditional Drying',
                  description: 'Coconuts are naturally sun-dried to achieve optimal moisture content.',
                },
                {
                  title: 'Wood-Pressed Extraction',
                  description: 'Using wooden cold-press machines (chekku) to extract pure oil.',
                },
                {
                  title: 'Natural Settling',
                  description: 'Oil is allowed to settle naturally, preserving all nutrients.',
                },
              ].map((step, index) => (
                <div key={index} className="flex gap-4">
                  <div className="shrink-0 w-10 h-10 bg-[#C9A227] text-[#123524] rounded-full flex items-center justify-center font-bold">
                    {index + 1}
                  </div>
                  <div>
                    <h4 className="font-semibold text-[#123524] mb-1">{step.title}</h4>
                    <p className="text-muted-foreground text-sm">{step.description}</p>
                  </div>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-16 md:py-24 bg-[#F8F5EF]">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <span className="text-[#C9A227] text-sm font-medium tracking-[0.2em] uppercase mb-2 block">
              Our Values
            </span>
            <h2 className="font-serif text-3xl md:text-4xl text-[#123524] font-bold">
              What We Stand For
            </h2>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {values.map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-white p-6 rounded-xl"
              >
                <div className="w-12 h-12 bg-[#123524] rounded-lg flex items-center justify-center mb-4">
                  <value.icon className="w-6 h-6 text-[#C9A227]" />
                </div>
                <h3 className="font-semibold text-[#123524] mb-2">{value.title}</h3>
                <p className="text-muted-foreground text-sm">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="py-16 md:py-24 bg-[#123524]">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <span className="text-[#C9A227] text-sm font-medium tracking-[0.2em] uppercase mb-2 block">
              Our Journey
            </span>
            <h2 className="font-serif text-3xl md:text-4xl text-white font-bold">
              Milestones Along the Way
            </h2>
          </motion.div>

          <div className="max-w-4xl mx-auto">
            {milestones.map((milestone, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: index % 2 === 0 ? -30 : 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="flex gap-4 md:gap-8 mb-8 last:mb-0"
              >
                <div className="shrink-0 w-16 md:w-20 text-right">
                  <span className="font-serif text-xl md:text-2xl text-[#C9A227] font-bold">
                    {milestone.year}
                  </span>
                </div>
                <div className="relative pb-8 border-l-2 border-[#C9A227]/30 pl-4 md:pl-8">
                  <div className="absolute left-0 top-1 w-3 h-3 bg-[#C9A227] rounded-full -translate-x-1/2" />
                  <h3 className="font-semibold text-white mb-1">{milestone.title}</h3>
                  <p className="text-white/70 text-sm">{milestone.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-16 md:py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="bg-[#F8F5EF] p-8 rounded-2xl"
            >
              <h3 className="font-serif text-2xl font-bold text-[#123524] mb-4">
                Our Mission
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                To bring the authentic goodness of traditional coconut oil to every 
                Indian home, while supporting sustainable farming practices and 
                empowering local communities in Udumalpet.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="bg-[#123524] p-8 rounded-2xl"
            >
              <h3 className="font-serif text-2xl font-bold text-white mb-4">
                Our Vision
              </h3>
              <p className="text-white/80 leading-relaxed">
                To become India&apos;s most trusted natural wellness brand, known for 
                our commitment to purity, tradition, and sustainability, inspiring 
                a healthier lifestyle through nature&apos;s gifts.
              </p>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  )
}
